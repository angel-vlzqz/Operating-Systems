To compile this file, we will be using pthreads in C, so run:
```
gcc -o run main.c -pthread
```

Once compiled, run:
```
./run
```
